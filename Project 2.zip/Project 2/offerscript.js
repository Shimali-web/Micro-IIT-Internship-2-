let currentPage = 1;
const itemsPerPage = 12;
const offerList = document.getElementById("offer-list");

// Sample Offer Data
const offers = [
    { title: "Buy 1 Get 1 Free", price: 19.99, image: "Images/offer1.jpg" },
    { title: "Flat 50% Off", price: 9.99, image: "Images/offer2.jpg" },
    { title: "Limited Time Deal", price: 14.99, image: "Images/offer3.jpg" },
    { title: "Exclusive Combo", price: 24.99, image: "Images/offer4.jpg" },
    { title: "New Season Sale", price: 29.99, image: "Images/offer5.jpg" },
    { title: "Flash Sale!", price: 34.99, image: "Images/offer6.jpg" },
    { title: "Special Festive Offer", price: 39.99, image: "Images/offer7.jpg" },
    { title: "Christmas Deals", price: 44.99, image: "Images/offer8.jpg" },
    { title: "Black Friday Sale", price: 49.99, image: "Images/offer9.jpg" },
    { title: "Mega Discount", price: 54.99, image: "Images/offer10.jpg" }
];

let cart = [];
const cartItems = document.getElementById("cart-items");
const cartTotal = document.getElementById("cart-total");

// Display Offers with Pagination
function showPage(page) {
    offerList.innerHTML = "";
    let start = (page - 1) * itemsPerPage;
    let end = start + itemsPerPage;

    offers.slice(start, end).forEach(offer => {
        let offerCard = document.createElement("div");
        offerCard.classList.add("offer-card");

        offerCard.innerHTML = `
            <img src="${offer.image}" class="offer-img">
            <h3 class="offer-title">${offer.title}</h3>
            <p class="offer-price">$${offer.price}</p>
            <button class="add-to-cart">Add to Cart</button>
        `;

        offerCard.querySelector(".add-to-cart").addEventListener("click", function () {
            addToCart(offer);
        });

        offerList.appendChild(offerCard);
    });

    document.getElementById("current-page").innerText = page;
}

// Add to Cart Function
function addToCart(offer) {
    cart.push(offer);
    updateCart();
}

// Update Cart Display
function updateCart() {
    cartItems.innerHTML = "";
    let total = 0;

    cart.forEach(item => {
        total += item.price;
        let li = document.createElement("li");
        li.textContent = `${item.title} - $${item.price}`;
        cartItems.appendChild(li);
    });

    cartTotal.innerText = total.toFixed(2);
}


// Pagination Buttons
document.getElementById("prev-page").addEventListener("click", function () {
    if (currentPage > 1) {
        currentPage--;
        showPage(currentPage);
    }
});

document.getElementById("next-page").addEventListener("click", function () {
    let totalPages = Math.ceil(offers.length / itemsPerPage);
    if (currentPage < totalPages) {
        currentPage++;
        showPage(currentPage);
    }
});

// Initialize Page
showPage(currentPage);
