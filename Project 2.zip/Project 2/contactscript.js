document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("contactForm");

    form.addEventListener("submit", function (e) {
        e.preventDefault();

        const name = document.getElementById("name").value.trim();
        const email = document.getElementById("email").value.trim();
        const message = document.getElementById("message").value.trim();

        if (name && email && message) {
            showPopup(`Thank you, ${name}! Your message has been sent successfully.`);
            form.reset();
        } else {
            showPopup("Please fill out all fields.");
        }
    });

    function showPopup(msg) {
        const popup = document.createElement("div");
        popup.className = "popup-alert";
        popup.innerText = msg;
        document.body.appendChild(popup);

        // Show the popup
        setTimeout(() => {
            popup.classList.add("show");
        }, 10);

        // Hide after 3 seconds
        setTimeout(() => {
            popup.classList.remove("show");
            setTimeout(() => popup.remove(), 300);
        }, 3000);
    }
});
