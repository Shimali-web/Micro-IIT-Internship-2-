document.addEventListener("DOMContentLoaded", () => {
    const cartButtons = document.querySelectorAll(".add-to-cart");

    cartButtons.forEach(button => {
        button.addEventListener("click", () => {
            alert("Item added to cart!");
        });
    });
});

// Show hover options when clicking a product
function showOptions(product) {
    // Close other open menus
    document.querySelectorAll(".product-options").forEach(menu => {
        if (menu !== product.querySelector(".product-options")) {
            menu.style.display = "none";
        }
    });

    // Toggle menu visibility
    let options = product.querySelector(".product-options");
    options.style.display = options.style.display === "block" ? "none" : "block";
}

// Close menu when clicking outside
document.addEventListener("click", (event) => {
    if (!event.target.closest(".product-card")) {
        document.querySelectorAll(".product-options").forEach(menu => {
            menu.style.display = "none";
        });
    }
});

//PRODUCT JS
let cart = [];
let currentPage = 1;
const productsPerPage = 12;

const allProducts = [
    { name: "T-Shirt", price: 19.99, image: "Images/tshirt.jpg", rating: 4 },
    { name: "Sneakers", price: 49.99, image: "Images/sneakers.jpg", rating: 5 },
    { name: "Jacket", price: 59.99, image: "Images/jacket.jpg", rating: 4 },
    { name: "Watch", price: 99.99, image: "Images/watch.jpg", rating: 5 },
    { name: "Cap", price: 15.99, image: "Images/cap.jpg", rating: 3 },
    { name: "Backpack", price: 79.99, image: "Images/backpack.jpg", rating: 5 },
    { name: "Shoes", price: 89.99, image: "Images/shoes .jpg", rating: 4 },
    { name: "Hoodie", price: 39.99, image: "Images/hoodie.jpg", rating: 4 },
    { name: "Jeans", price: 44.99, image: "Images/jeans.jpg", rating: 5 },
    { name: "Socks", price: 9.99, image: "Images/socks.jpg", rating: 4 },
    { name: "Gloves", price: 14.99, image: "Images/gloves.jpg", rating: 3 },
    { name: "Sunscreen", price: 34.99, image: "Images/sunscreen.jpg", rating: 5 },
   
];

function displayProducts(page) {
    const productContainer = document.getElementById("product-list");
    productContainer.innerHTML = "";

    const start = (page - 1) * productsPerPage;
    const end = start + productsPerPage;
    const paginatedProducts = allProducts.slice(start, end);

    paginatedProducts.forEach(product => {
        productContainer.innerHTML += `
            <div class="product-card">
                <img src="${product.image}" alt="${product.name}">
                <h3>${product.name}</h3>
                <p>$${product.price.toFixed(2)}</p>
                <div class="rating">${"⭐".repeat(product.rating)}</div>
                <div class="hover-options">
                    <button onclick="addToCart('${product.name}', ${product.price})">Add to Cart</button>
                </div>
            </div>
        `;
    });

    document.getElementById("page-number").innerText = page;
}

function addToCart(name, price) {
    cart.push({ name, price });
    updateCart();
}

function updateCart() {
    const cartList = document.getElementById("cart-items");
    cartList.innerHTML = "";

    let total = 0;
    cart.forEach(item => {
        total += item.price;
        const li = document.createElement("li");
        li.textContent = `${item.name} - $${item.price.toFixed(2)}`;
        cartList.appendChild(li);
    });

    // Ensure cart total is always visible
    document.getElementById("cart-total").innerText = total.toFixed(2);
    document.getElementById("cart-count").innerText = cart.length;
}


// Cart Toggle
document.getElementById("cart-btn").addEventListener("click", () => {
    document.getElementById("cart").classList.toggle("open");
});

displayProducts(currentPage);


