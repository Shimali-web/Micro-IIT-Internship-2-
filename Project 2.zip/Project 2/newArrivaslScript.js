document.addEventListener("DOMContentLoaded", function () {
    const productsPerPage = 12;
    let currentPage = 1;
    let cart = [];
    
    const products = [
        { id: 1, name: "Red Sneakers", price: 59.99, image: "Images/shoe1.jpg" },
        { id: 2, name: "Blue Hoodie", price: 79.99, image: "Images/blue-hoodie.jpg" },
        { id: 3, name: "Classic Watch", price: 129.99, image: "Images/classic-watch.jpg" },
        { id: 4, name: "Casual Shirt", price: 49.99, image: "Images/shirt.jpg" },
        { id: 5, name: "Trendy Jacket", price: 99.99, image: "Images/trendy-jacket.jpg" },
        { id: 6, name: "Slim Fit Jeans", price: 69.99, image: "Images/fit-jeans.jpg" },
        { id: 7, name: "Leather Wallet", price: 39.99, image: "Images/wallet.jpg" },
        { id: 8, name: "Running Shoes", price: 89.99, image: "Images/shoe2.jpg" },
        { id: 9, name: "Winter Coat", price: 149.99, image: "Images/coat.jpg" },
        { id: 10, name: "Stylish Cap", price: 19.99, image: "Images/stylish-cap.jpg" },
        { id: 11, name: "Black Sunglasses", price: 59.99, image: "Images/sunglasses.jpg" },
        { id: 12, name: "Digital Watch", price: 99.99, image: "Images/digitalwatch.jpg" }
    ];

    function displayProducts() {
        const productContainer = document.getElementById("product-list");
        productContainer.innerHTML = "";

        let start = (currentPage - 1) * productsPerPage;
        let end = start + productsPerPage;
        let paginatedProducts = products.slice(start, end);

        paginatedProducts.forEach((product) => {
            let productCard = document.createElement("div");
            productCard.classList.add("product-card");

            productCard.innerHTML = `
                <img src="${product.image}" alt="${product.name}">
                <div class="product-info">
                    <h3>${product.name}</h3>
                    <p>⭐ 4.5 | 💲${product.price.toFixed(2)}</p>
                    <button class="add-to-cart" data-id="${product.id}">Add to Cart</button>
                </div>
            `;

            productContainer.appendChild(productCard);
        });

        document.querySelectorAll(".add-to-cart").forEach((button) => {
            button.addEventListener("click", addToCart);
        });
    }

    function updateCart() {
        const cartList = document.getElementById("cart-items");
        const cartTotal = document.getElementById("cart-total");

        cartList.innerHTML = "";
        let total = 0;

        cart.forEach((item) => {
            total += item.price;
            let li = document.createElement("li");
            li.textContent = `${item.name} - $${item.price.toFixed(2)}`;
            cartList.appendChild(li);
        });

        cartTotal.textContent = total.toFixed(2);
    }

    function addToCart(event) {
        let productId = parseInt(event.target.dataset.id);
        let product = products.find((p) => p.id === productId);
        cart.push(product);
        updateCart();
    }

    document.getElementById("prev-page").addEventListener("click", function () {
        if (currentPage > 1) {
            currentPage--;
            displayProducts();
            document.getElementById("current-page").textContent = currentPage;
        }
    });

    document.getElementById("next-page").addEventListener("click", function () {
        if (currentPage < Math.ceil(products.length / productsPerPage)) {
            currentPage++;
            displayProducts();
            document.getElementById("current-page").textContent = currentPage;
        }
    });

    displayProducts();
});
